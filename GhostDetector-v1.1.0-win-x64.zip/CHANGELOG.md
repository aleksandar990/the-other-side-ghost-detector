# v1.1.0

- Automatic discovery from a running game, Steam libraries and common local installation folders.
- Launcher selection resolves to the actual shipping executable.
- Per-user settings stored outside the application folder.
- Windows account names redacted from game-path display, errors and logs.
- Button hover/press transitions, page transitions and new-identity reveal animations, respecting Windows animation and High Contrast preferences.
- Simplified desktop interface and sourced ghost reference details.
- Public source and runtime packaging use strict allowlists and exclude local development data.

The runtime reader still supports one inspected executable fingerprint. A game update may require a newly verified integration profile.
