# Third-party notices

Barlow and Rajdhani fonts are redistributed under their included SIL Open Font License notices in `GhostDetector/Assets/Fonts`. These licenses and author credits remain intact.

Ghost reference data is sourced from the community P.M.S. Tracker: https://p8riot.github.io/tos-ghost-tracker/Index.html . Source and retrieval information are recorded in `catalog.json` and `ghost-details.json`. Reference facts may differ from the installed game version.

This project is an unofficial companion and is not affiliated with the game developer. Game executables, assets and account information are not distributed. Historical generated artwork is not used by the current interface.
