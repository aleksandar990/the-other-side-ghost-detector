# The Other Side — Ghost Detector

Unofficial Windows companion built with C# / WPF and .NET 8. Shows the current ghost from a supported game build, monitors contract changes, and provides separately labeled community reference details.

## Install and connect

1. Install the [.NET 8 Desktop Runtime for Windows x64](https://dotnet.microsoft.com/en-us/download/dotnet/8.0).
2. Extract the entire Windows release ZIP into a folder and run `GhostDetector.exe`.
3. Start The Other Side. The app searches running processes, Steam library folders, Downloads and Desktop (bounded depth/time).
4. Press **INJECT** to connect. This button starts a read-only reader; it does not inject code.
5. If discovery fails, open Connection and choose `TheOtherSide.exe` or `TheOtherSide-Win64-Shipping.exe`. Launcher selection resolves to the shipping executable when present.
6. **Find ghost** reconnects and refreshes. New matches refresh automatically after connection.

Discovery identifies an installation candidate, not a verified identity or supported build. The runtime reader independently checks the exact executable SHA-256 before using its profile:

```
20c4fcb0cba38320de5c9ae0b4f6f67bf500f24eef670f2e2d73188596f61e65
```

Other builds are rejected. Support for every current or future game version is not claimed. Lobby/loading states and acquisition errors display an unknown identity. Community evidence and behavior details are reference facts, not live measurements. Retained previous results are labeled.

## Privacy

No account, login, API key or `game-path.txt` is needed. The game path is discovered locally and saved in `%LOCALAPPDATA%/OtherSideGhostDetector/settings.json`. Displayed game paths and diagnostic logs replace Windows user directories with `%USERPROFILE%`. Settings and logs remain on the user's machine; the app does not upload them.

Per-user settings and logs must not be committed or included in a release. The clean release script excludes those files, debug symbols, captures, research notes and development previews. Existing Git history and GitHub profile identity require a separate review before publishing. Do not upload the whole development folder.

## Build

Install the [.NET 8 SDK](https://dotnet.microsoft.com/en-us/download/dotnet/8.0), then run PowerShell from the repository root:

```powershell
dotnet restore GhostDetector/GhostDetector.csproj
./build.ps1 -Publish
```

Output: `artifacts/public-build`. To publish with an explicit SDK path, pass `-DotnetPath`. A self-contained build is available with `-SelfContained` and requires downloading runtime packs.

Tests:

```powershell
dotnet run --project Tests/Tests.csproj -c Release
```

A diagnostic command verifies real WPF animation clocks without showing or capturing the desktop:

```powershell
./artifacts/public-build/GhostDetector.exe --motion-check artifacts/motion-check
```

The production app respects Windows animation settings and High Contrast. The diagnostic temporarily exercises clocks inside its own process; it does not change Windows settings.

## Make public packages

Install Python 3 and run:

```powershell
./build.ps1 -Publish
python tools/package_release.py
```

Only publish the files generated in `release-output`. The source ZIP contains the repository files to upload; the Windows ZIP is the downloadable Release asset. The script uses a strict allowlist, excludes personal/local files and checks package contents for developer profile paths. It does not change or publish your GitHub account, repository or Git history.

## Troubleshooting

- **Game not found:** launch the game before pressing INJECT, or choose its executable manually. Arbitrary custom drives are not exhaustively scanned.
- **Unsupported build:** the installed executable does not match the verified profile. No speculative offsets are used.
- **Access denied:** game-process permissions prevent the read. Diagnostics reports the error; no protection bypass is attempted.
- **Unknown in a match:** wait for loading to finish, check diagnostics, then retry Find ghost. Unknown is preferable to an unverified result.
- **No animations:** enable Animation effects in Windows Accessibility settings. High Contrast also disables app motion.
- **Missing runtime:** install the x64 .NET 8 Desktop Runtime, not only the base runtime.

Open local logs from Connection. Logs are stored under `%LOCALAPPDATA%/OtherSideGhostDetector/Logs` and are not uploaded.

## Scope

The supported runtime reader uses read-only process access. It does not write game memory, load code into the game, bypass anti-cheat, intercept traffic or submit an answer. Use the in-game phone's Identifier app to submit your ghost selection before ending the contract.

## License and reference

Project code: MIT. See LICENSE and NOTICE.md. Font licenses are included. Ghost facts are sourced from the [P.M.S. Tracker](https://p8riot.github.io/tos-ghost-tracker/Index.html). No game executable or game assets are included.
