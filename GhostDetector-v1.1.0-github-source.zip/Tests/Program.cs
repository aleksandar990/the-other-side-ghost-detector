using GhostDetector;
using System.Text.Json;

int checks = 0;
void Check(bool condition, string message)
{ if (!condition) throw new Exception("FAIL: " + message); checks++; Console.WriteLine("PASS: " + message); }
async Task Reject(Func<Task> action, string message)
{
    try { await action(); } catch (Exception ex) when (ex is InvalidDataException or JsonException or FileNotFoundException)
    { Check(true, message); return; }
    throw new Exception("FAIL: " + message);
}
var catalog = Catalog.Load(Path.Combine(AppContext.BaseDirectory, "catalog.json"));
var engine = new EvidenceIdentifier(catalog);
SessionSnapshot Snapshot(Dictionary<string, Observation>? ev = null, int count = 3) =>
    new(1, "test-match", "test-location", "Identify", "Active", DateTimeOffset.UtcNow, count, ev ?? new());
Check(catalog.Ghosts.Length == 25, "sourced catalog contains 25 entries");
Check(engine.Identify(Snapshot()).Candidates.Length == 25, "unknown evidence preserves all candidates");
Check(engine.Identify(Snapshot(new() { ["Audio"] = Observation.Real, ["EMF"] = Observation.Real, ["Radiation"] = Observation.Real })).Candidates.Single().Name == "Banshee", "known sourced triple filters to Banshee");
Check(!engine.Identify(Snapshot(new() { ["EMF"] = Observation.Real }, 1)).Candidates.Any(x => x.Name == "Banshee"), "forced Audio eliminates Banshee when one-evidence contract is filled");
Check(engine.Identify(Snapshot(new() { ["UV"] = Observation.Diminishing })).Candidates.Length == 25, "diminishing evidence does not create false exclusions");
Check(!engine.Identify(Snapshot(new() { ["Audio"] = Observation.RuledOut })).Candidates.Any(x => x.Name == "Banshee"), "explicit rule-out removes incompatible ghosts");
Check(engine.Identify(Snapshot() with { Mode = "Cleanse" }).Candidates.Length == 0, "Cleanse never reuses Identify predictions");
Check(engine.Identify(Snapshot() with { Status = "Ended" }).Candidates.Length == 0, "ended match clears predictions");
await Reject(() => Task.Run(() => engine.Identify(Snapshot(new() { ["Freezing"] = Observation.Diminishing }))), "invalid diminishing Freezing rejected");
await Reject(() => Task.Run(() => engine.Identify(Snapshot(new() { ["Imaginary"] = Observation.Real }))), "unknown evidence rejected");
await Reject(() => Task.Run(() => engine.Identify(Snapshot(new() { ["Audio"] = Observation.Real }, 0))), "contradictory contract evidence rejected");
string dir = Path.Combine(Path.GetTempPath(), "GhostDetectorTests-" + Guid.NewGuid().ToString("N"));
Directory.CreateDirectory(dir);
string path = Path.Combine(dir, "observations.json");
var fileSource = new ObservationFileSource(path, engine);
async Task Write(SessionSnapshot s) => await File.WriteAllTextAsync(path, JsonSerializer.Serialize(s, Json.Options));
try
{
    await Reject(async () => { await fileSource.ReadAsync(default); }, "missing source fails honestly");
    await Write(Snapshot());
    Check((await fileSource.ReadAsync(default)).MatchId == "test-match", "read-only source parses valid snapshot");
    await Write(Snapshot() with { ObservedUtc = DateTimeOffset.UtcNow.AddMinutes(-1) });
    await Reject(async () => { await fileSource.ReadAsync(default); }, "stale feed rejected");
    await Write(Snapshot() with { ObservedUtc = DateTimeOffset.UtcNow.AddMinutes(1) });
    await Reject(async () => { await fileSource.ReadAsync(default); }, "future timestamps rejected");
    await File.WriteAllTextAsync(path, "{");
    await Reject(async () => { await fileSource.ReadAsync(default); }, "partial JSON rejected");
    await File.WriteAllTextAsync(path, new string(' ', 70000));
    await Reject(async () => { await fileSource.ReadAsync(default); }, "oversized file rejected");
    // Exercise actual retry, replacement snapshot, match transition, and cancellation.
    await File.WriteAllTextAsync(path, "{");
    using var stop = new CancellationTokenSource(TimeSpan.FromSeconds(15));
    var updates = new List<MonitorUpdate>();
    var monitor = new MatchMonitor(fileSource, new AppLog());
    var run = monitor.RunAsync(u =>
    {
        updates.Add(u);
        if (u.Snapshot is null) Write(Snapshot()).GetAwaiter().GetResult();
        else if (u.Snapshot.MatchId == "test-match") Write(Snapshot() with { MatchId = "next-match" }).GetAwaiter().GetResult();
        else stop.Cancel();
    }, stop.Token);
    await run;
    Check(updates.First().Snapshot is null, "failed read publishes cleared state");
    Check(updates.Any(x => x.Snapshot?.MatchId == "test-match"), "monitor recovers automatically after malformed input");
    Check(updates.Last().Snapshot?.MatchId == "next-match", "monitor observes match transition without reconnect");
}
finally
{
    // Only the exact two test-owned paths are removed; no recursive deletion.
    if (File.Exists(path)) File.Delete(path);
    Directory.Delete(dir);
}
var connection = new GameConnection();
string ownExecutable = Environment.ProcessPath ?? throw new Exception("Missing test executable path");
Check((await connection.FindAsync(ownExecutable, default))?.Id == Environment.ProcessId, "process binding verifies exact selected executable");
await Reject(() => Task.Run(() => { using var unsupported = new RuntimeGhostReader(new(Environment.ProcessId,ownExecutable)); }), "runtime reader rejects unsupported fingerprint before applying profile");
await Reject(async () => { await connection.FindAsync(Path.Combine(dir, "missing.exe"), default); }, "missing game executable cannot connect");
using (var cancelled = new CancellationTokenSource())
{
    cancelled.Cancel();
    try { await connection.FindAsync(ownExecutable, cancelled.Token); throw new Exception("Cancellation ignored"); }
    catch (OperationCanceledException) { Check(true, "process lookup respects cancellation"); }
}
var reference=GhostReference.Load(Path.Combine(AppContext.BaseDirectory,"ghost-details.json"));
Check(reference.Find("Strigoi")?.Evidence.SequenceEqual(new[]{"Freezing","UV","Writing"})==true,"Strigoi dossier loads the sourced evidence profile");
Check(reference.Find("TheEcho")?.Name=="Echo","native enum name maps to matching dossier");
Check(reference.Find("Doppleganger")?.Name=="Doppelganger","native spelling maps without selecting another ghost");
Check(reference.Find("UnknownGhost") is null,"unknown identity gets no invented dossier");
string discoveryRoot=Path.Combine(Path.GetTempPath(),"GhostDiscovery-"+Guid.NewGuid().ToString("N"));
try
{
    string install=Path.Combine(discoveryRoot,"Games","The Other Side");
    string shipping=Path.Combine(install,"TheOtherSide","Binaries","Win64",GameLocator.ShippingName);
    Directory.CreateDirectory(Path.GetDirectoryName(shipping)!);
    File.WriteAllText(shipping,"discovery fixture, not executable game data");
    string launcher=Path.Combine(install,"TheOtherSide.exe");File.WriteAllText(launcher,"");
    Check(GameLocator.Resolve(launcher)==shipping,"launcher selection resolves to the shipping executable");
    Check(GameLocator.FindInRoots(new[]{discoveryRoot},default)==shipping,"bounded discovery finds a nested installation");
    Check(GameLocator.Resolve(Path.Combine(discoveryRoot,"missing.exe")) is null,"missing installation is never claimed as found");
    using var stopped=new CancellationTokenSource();stopped.Cancel();
    try {GameLocator.FindInRoots(new[]{discoveryRoot},stopped.Token);throw new Exception("Discovery ignored cancellation");}
    catch(OperationCanceledException){Check(true,"game discovery respects cancellation");}
}
finally {Directory.Delete(discoveryRoot,true);}
Check(Privacy.Redact(@"C:\Users\ExampleAccount\Downloads\game.exe")==@"%USERPROFILE%\Downloads\game.exe","Windows account name is hidden in displayed paths");
Check(Privacy.Redact(@"Error at D:/Users/ExampleAccount/game.exe")=="Error at %USERPROFILE%/game.exe","alternate drive and slash style is redacted");
Check(Privacy.Redact("No process found")=="No process found","redaction preserves ordinary diagnostics");
Console.WriteLine($"All {checks} checks passed.");
