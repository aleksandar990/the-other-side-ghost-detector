"""Create public packages from explicit allowlists; never archive the workspace."""
from pathlib import Path
import hashlib
import json
import re
import zipfile

ROOT = Path(__file__).resolve().parents[1]
OUTPUT = ROOT / 'release-output'
VERSION = '1.1.0'


def audit(files):
    # Check actual developer profile roots in UTF-8 and UTF-16, including binaries.
    match = re.search(r'(?i)([a-z]:[\\/]Users[\\/]([^\\/]+))', str(ROOT))
    private = [match.group(1), match.group(2)] if match else []
    if match:
        private.extend(part for part in match.group(2).split() if len(part) >= 4)
        short = re.sub('[^a-zA-Z0-9]', '', match.group(2))[:6] + '~1'
        if len(short) >= 5:
            private.append(short)
    for relative, data in files.items():
        name = relative.lower()
        if any(part in name.split('/') for part in ('research', 'logs', 'captures', 'bin', 'obj', '.git')):
            raise ValueError(f'Private/generated directory included: {relative}')
        if name.endswith(('.pdb', '.log', '.sav', '.user')) or Path(name).name in ('game-path.txt', 'settings.json', 'agents.md'):
            raise ValueError(f'Local-only file included: {relative}')
        for term in private:
            for spelling in (term, term.replace('\\', '/')):
                for encoding in ('utf-8', 'utf-16-le'):
                    if spelling.lower().encode(encoding) in data.lower():
                        raise ValueError(f'Developer profile information detected in {relative}')


def archive(name, files):
    audit(files)
    target = OUTPUT / name
    with zipfile.ZipFile(target, 'w', zipfile.ZIP_DEFLATED) as z:
        for relative, data in sorted(files.items()):
            z.writestr(relative, data)
    with zipfile.ZipFile(target) as z:
        if z.testzip() is not None:
            raise ValueError(f'Archive integrity failed: {name}')
    return target


def main():
    OUTPUT.mkdir(exist_ok=True)
    source_paths = [ROOT / name for name in (
        'README.md', 'LICENSE', 'NOTICE.md', 'CHANGELOG.md', 'RELEASE-CHECKLIST.md',
        '.gitignore', 'build.ps1', 'VALIDATION.md', 'tools/package_release.py', 'Tests/Program.cs', 'Tests/Tests.csproj')]
    app = ROOT / 'GhostDetector'
    for pattern in ('*.cs', '*.xaml', '*.csproj', 'catalog.json', 'ghost-details.json', 'Assets/Fonts/*.ttf', 'Assets/Fonts/*-OFL.txt'):
        source_paths.extend(app.glob(pattern))
    source = {p.relative_to(ROOT).as_posix(): p.read_bytes() for p in source_paths}
    built = ROOT / 'artifacts/public-build'
    runtime_names = ('GhostDetector.exe', 'GhostDetector.dll', 'GhostDetector.deps.json',
                     'GhostDetector.runtimeconfig.json', 'catalog.json', 'ghost-details.json')
    runtime = {name: (built / name).read_bytes() for name in runtime_names}
    options=json.loads(runtime['GhostDetector.runtimeconfig.json'])['runtimeOptions']
    if 'framework' not in options and 'frameworks' not in options:
        raise ValueError('Use a framework-dependent publish for this packaging script (omit -SelfContained).')
    for name in ('README.md', 'LICENSE', 'NOTICE.md', 'CHANGELOG.md', 'VALIDATION.md'):
        runtime[name] = (ROOT / name).read_bytes()
    for p in (app / 'Assets/Fonts').glob('*-OFL.txt'):
        runtime['Licenses/' + p.name] = p.read_bytes()
    if b'1.1.0' not in runtime['GhostDetector.deps.json']:
        raise ValueError('Publish version 1.1.0 before packaging.')
    # Verify project links in the source archive do not depend on excluded material.
    project = source['GhostDetector/GhostDetector.csproj'].decode('utf-8')
    if 'Assets\\Artwork' in project:
        raise ValueError('Remove unused artwork resources before public packaging.')
    packages = [archive(f'GhostDetector-v{VERSION}-github-source.zip', source),
                archive(f'GhostDetector-v{VERSION}-win-x64.zip', runtime)]
    sums = ''.join(hashlib.sha256(p.read_bytes()).hexdigest() + '  ' + p.name + '\n' for p in packages)
    (OUTPUT / 'SHA256SUMS.txt').write_text(sums, encoding='ascii')
    report = {'version': VERSION, 'sourceFiles': sorted(source), 'runtimeFiles': sorted(runtime),
              'archiveIntegrity': 'passed', 'developerProfileScan': 'passed',
              'localSettingsLogsCapturesDebugSymbols': 'excluded', 'published': False}
    (OUTPUT / 'RELEASE-VALIDATION.json').write_text(json.dumps(report, indent=2), encoding='utf-8')
    print('Public source and Windows packages created. Integrity and profile-data checks passed.')


if __name__ == '__main__':
    main()
