# Publishing

1. Upload the contents of the **GitHub source ZIP** to your repository. Do not upload the surrounding development workspace.
2. Use `GhostDetector-v1.1.0-win-x64.zip` as the downloadable GitHub Release asset. Users extract the complete ZIP and run `GhostDetector.exe`.
3. Include `SHA256SUMS.txt` with the release assets.
4. Use the release notes from `CHANGELOG.md`.
5. Review your GitHub profile, repository owner, commit author and screenshot contents separately. Source-file cleanup does not change your GitHub account identity or existing Git history.

The application ZIP deliberately excludes local settings, `game-path.txt`, logs, debug symbols, captures and investigation files. Users' local paths are discovered at runtime. Do not add these files to a release manually.

The executable is unsigned. This package is a public test build. The inspected game fingerprint is documented in README; compatibility with other versions is not established.
