param([switch]$Publish, [switch]$SelfContained, [string]$DotnetPath = '')
$ErrorActionPreference = 'Stop'
$taskRoot = $PSScriptRoot
$privateSdk = Join-Path $taskRoot '.sdk\dotnet.exe'
$dotnetExe = if ($DotnetPath) { $DotnetPath } elseif (Test-Path -LiteralPath $privateSdk) { $privateSdk } else { 'dotnet' }
$env:DOTNET_CLI_HOME = Join-Path $taskRoot '.sdk\cli-home'
$env:NUGET_PACKAGES = Join-Path $taskRoot '.nuget\packages'
& $dotnetExe build (Join-Path $taskRoot 'GhostDetector\GhostDetector.csproj') -c Release
if ($LASTEXITCODE -ne 0) { throw 'Application build failed.' }
& $dotnetExe run --project (Join-Path $taskRoot 'Tests\Tests.csproj') -c Release
if ($LASTEXITCODE -ne 0) { throw 'Backend checks failed.' }
if ($Publish) {
 $contained = if ($SelfContained) { 'true' } else { 'false' }
 & $dotnetExe publish (Join-Path $taskRoot 'GhostDetector\GhostDetector.csproj') -c Release -r win-x64 --self-contained $contained -o (Join-Path $taskRoot 'artifacts\public-build')
 if ($LASTEXITCODE -ne 0) { throw 'Publishing failed.' }
}
