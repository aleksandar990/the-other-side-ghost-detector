using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;

namespace GhostDetector;

public static class UiMotion
{
    // Static own-tree previews always render the settled state.
    public static bool Suppress { get; set; }
    internal static bool ValidationOverride {get;set;}
    public static bool CanAnimate => !Suppress && (ValidationOverride || SystemParameters.ClientAreaAnimation) && !SystemParameters.HighContrast;
    public static readonly DependencyProperty InteractiveProperty = DependencyProperty.RegisterAttached(
        "Interactive", typeof(bool), typeof(UiMotion), new PropertyMetadata(false, InteractiveChanged));
    public static void SetInteractive(DependencyObject target, bool value) => target.SetValue(InteractiveProperty,value);
    public static bool GetInteractive(DependencyObject target) => (bool)target.GetValue(InteractiveProperty);

    private static void InteractiveChanged(DependencyObject target, DependencyPropertyChangedEventArgs args)
    {
        if(target is not Button button)return;
        if((bool)args.NewValue)
        {
            button.MouseEnter+=FeedbackChanged; button.MouseLeave+=FeedbackChanged;
            button.PreviewMouseLeftButtonDown+=FeedbackChanged; button.PreviewMouseLeftButtonUp+=FeedbackChanged;
            button.GotKeyboardFocus+=FeedbackChanged; button.LostKeyboardFocus+=FeedbackChanged;
            button.PreviewKeyDown+=FeedbackChanged; button.PreviewKeyUp+=FeedbackChanged;
            button.IsEnabledChanged+=EnabledChanged;
        }
        else
        {
            button.MouseEnter-=FeedbackChanged; button.MouseLeave-=FeedbackChanged;
            button.PreviewMouseLeftButtonDown-=FeedbackChanged; button.PreviewMouseLeftButtonUp-=FeedbackChanged;
            button.GotKeyboardFocus-=FeedbackChanged; button.LostKeyboardFocus-=FeedbackChanged;
            button.PreviewKeyDown-=FeedbackChanged; button.PreviewKeyUp-=FeedbackChanged;
            button.IsEnabledChanged-=EnabledChanged;
            Feedback(button,0);
        }
    }
    private static void EnabledChanged(object sender,DependencyPropertyChangedEventArgs args)
    {
        var button=(Button)sender;
        Feedback(button,button.IsEnabled && (button.IsMouseOver || button.IsKeyboardFocused)?0.07:0);
    }
    private static void FeedbackChanged(object sender,RoutedEventArgs args)
    {
        var button=(Button)sender;
        bool down=args.RoutedEvent==UIElement.PreviewMouseLeftButtonDownEvent ||
            args is KeyEventArgs key && key.RoutedEvent==Keyboard.PreviewKeyDownEvent && key.Key==Key.Space;
        double opacity=!button.IsEnabled?0:down?0.15:button.IsMouseOver||button.IsKeyboardFocused?0.07:0;
        if(args.RoutedEvent==UIElement.MouseLeaveEvent && !button.IsKeyboardFocused)opacity=0;
        Feedback(button,opacity);
    }
    internal static void Feedback(Button button,double opacity)
    {
        button.ApplyTemplate();
        if(button.Template.FindName("HoverOverlay",button) is not Border overlay)return;
        double start=overlay.Opacity;
        overlay.BeginAnimation(UIElement.OpacityProperty,null);
        overlay.Opacity=opacity;
        if(CanAnimate)overlay.BeginAnimation(UIElement.OpacityProperty,Tween(start,opacity,opacity>0.1?70:140));
    }
    public static void Reveal(UIElement element)
    {
        element.BeginAnimation(UIElement.OpacityProperty,null);
        element.Opacity=1;
        if(element.RenderTransform is not TranslateTransform move)
        {
            move=new TranslateTransform();
            element.RenderTransform=move;
        }
        move.BeginAnimation(TranslateTransform.YProperty,null);
        move.Y=0;
        if(!CanAnimate)return;
        element.BeginAnimation(UIElement.OpacityProperty,Tween(0.45,1,200));
        move.BeginAnimation(TranslateTransform.YProperty,Tween(6,0,200));
    }
    private static DoubleAnimation Tween(double from,double to,int milliseconds)=>new(from,to,TimeSpan.FromMilliseconds(milliseconds))
    {
        EasingFunction=new CubicEase {EasingMode=EasingMode.EaseOut},
        FillBehavior=FillBehavior.Stop
    };
}
