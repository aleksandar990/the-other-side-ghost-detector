using System.Diagnostics;
using System.IO;

namespace GhostDetector;

public sealed record GameProcess(int Id, string ExecutablePath);

// Binds only to the exact executable chosen by the operator. Process existence is
// reported separately from match/identity access; it cannot establish either.
public sealed class GameConnection
{
    public Task<GameProcess?> FindAsync(string executablePath, CancellationToken token) => Task.Run(() =>
    {
        string fullPath = Path.GetFullPath(executablePath);
        if (!File.Exists(fullPath) || !string.Equals(Path.GetExtension(fullPath), ".exe", StringComparison.OrdinalIgnoreCase))
            throw new InvalidDataException("Select the installed game's actual .exe file.");
        var matches = new List<GameProcess>();
        foreach (var process in Process.GetProcessesByName(Path.GetFileNameWithoutExtension(fullPath)))
        {
            using (process)
            {
                token.ThrowIfCancellationRequested();
                try
                {
                    string? runningPath = process.MainModule?.FileName;
                    if (runningPath is not null && string.Equals(fullPath, Path.GetFullPath(runningPath), StringComparison.OrdinalIgnoreCase))
                        matches.Add(new(process.Id, fullPath));
                }
                catch (InvalidOperationException) { /* Process exited during enumeration. */ }
                catch (System.ComponentModel.Win32Exception ex)
                { throw new IOException("Windows could not verify a matching process's executable path. " + ex.Message, ex); }
            }
        }
        if (matches.Count > 1) throw new InvalidDataException("Multiple instances of the selected executable are running. Close the extra instance.");
        return matches.SingleOrDefault();
    }, token);
}
