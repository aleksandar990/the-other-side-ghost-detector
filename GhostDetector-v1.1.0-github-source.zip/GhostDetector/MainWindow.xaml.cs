using System.IO;
using System.Diagnostics;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;
using Microsoft.Win32;

namespace GhostDetector;

public partial class MainWindow : Window
{
    private readonly AppLog log = new();
    private Catalog? catalog;
    private EvidenceIdentifier? identifier;
    private readonly Dictionary<string, ComboBox> evidenceControls = new();
    private CancellationTokenSource? cancellation;
    private Task? monitoring;
    private int generation;
    private bool ready, manualRunning, changing;
    private string matchStatus = "Waiting";
    private string? gameExecutable;
    private CancellationTokenSource? gameCancellation;
    private GameProcess? boundGame;
    private GhostReference? ghostReference;
    private RuntimeIdentity? lastIdentity;
    private readonly CancellationTokenSource discoveryCancellation=new();
    private Task<string?>? discoveryTask;

    public MainWindow()
    {
        InitializeComponent();
        string[] navigationNames={"Overview","Ghost dossier","Evidence","Connection"};
        for(int tabIndex=0;tabIndex<navigationNames.Length;tabIndex++)
            System.Windows.Automation.AutomationProperties.SetName((TabItem)WorkspaceTabs.Items[tabIndex],navigationNames[tabIndex]);
        try
        {
            catalog = Catalog.Load(Path.Combine(AppContext.BaseDirectory, "catalog.json"));
            identifier = new(catalog);
            try { ghostReference=GhostReference.Load(Path.Combine(AppContext.BaseDirectory,"ghost-details.json")); }
            catch(Exception ex) when(ex is IOException or InvalidDataException or System.Text.Json.JsonException)
            { log.Write("Ghost details unavailable: "+ex.Message); }
            foreach (string evidence in catalog.EvidenceTypes)
            {
                var panel = new StackPanel();
                panel.Children.Add(new TextBlock { Text = evidence == "EMF" ? "EMF 20+" : evidence, FontWeight = FontWeights.SemiBold, Margin = new Thickness(0,0,0,8) });
                var box = new ComboBox { ItemsSource = Enum.GetValues<Observation>(), SelectedIndex = 0, MinWidth = 170, Margin = new Thickness(0,6,0,0) };
                System.Windows.Automation.AutomationProperties.SetName(box, evidence + " observation");
                box.SelectionChanged += Manual_Changed;
                evidenceControls.Add(evidence, box);
                panel.Children.Add(box);
                EvidencePanel.Children.Add(new Border { Child = panel, Background = new SolidColorBrush(Color.FromRgb(23,24,30)), BorderBrush = new SolidColorBrush(Color.FromRgb(62,56,70)), BorderThickness = new Thickness(1), CornerRadius = new CornerRadius(12), Padding = new Thickness(16), Margin = new Thickness(0,0,12,12) });
            }
            CatalogText.Text = $"Community reference: {catalog.Source}\nCatalog {catalog.Version} • retrieved {catalog.RetrievedUtc} • {catalog.Ghosts.Length} ghosts • verify against your installed game guide after updates.";
            ResetMatch();
            var saved=LocalGameSettings.Load();
            if(saved is not null && GameLocator.Resolve(saved) is string installed)SetGamePath(installed);
            ready = true;
        }
        catch (Exception ex) when (ex is IOException or InvalidDataException or System.Text.Json.JsonException or ArgumentException)
        {
            ErrorText.Text=Privacy.Redact("Cannot initialize detector: " + ex.Message);
            InjectButton.IsEnabled = false;
            log.Write(ex.ToString());
        }
        Closed += (_, _) => { Stop(); gameCancellation?.Cancel(); discoveryCancellation.Cancel(); };
        Loaded+=async (_,_)=>await DiscoverGameAsync();
        WorkspaceTabs.SelectionChanged+=(_,args)=>
        {
            if(ReferenceEquals(args.OriginalSource,WorkspaceTabs) && WorkspaceTabs.SelectedContent is UIElement page)
                UiMotion.Reveal(page);
        };
    }

    private void SetGamePath(string executable)
    {
        gameExecutable=executable;
        GamePathText.Text=Privacy.Redact(executable);
        LocalGameSettings.Save(executable);
    }
    private async Task DiscoverGameAsync()
    {
        if(gameExecutable is not null)return;
        GamePathText.Text="Looking for the game…";
        try
        {
            discoveryTask??=new GameLocator().LocateAsync(discoveryCancellation.Token);
            string? found=await discoveryTask;
            if(discoveryCancellation.IsCancellationRequested || gameExecutable is not null)return;
            if(found is not null){SetGamePath(found);GameStatusText.Text="Game found. Launch it and press INJECT to connect.";}
            else {GamePathText.Text="Game not found. Launch it and press INJECT, or choose the executable.";discoveryTask=null;}
        }
        catch(OperationCanceledException) { }
        catch(Exception ex) when(ex is IOException or UnauthorizedAccessException or ArgumentException)
        {GamePathText.Text="Automatic discovery failed. Choose the executable.";log.Write(ex.Message);discoveryTask=null;}
    }

    private void GameBrowse_Click(object sender, RoutedEventArgs e)
    {
        var dialog = new OpenFileDialog { Filter = "Game executable (*.exe)|*.exe", CheckFileExists = true };
        if (dialog.ShowDialog() != true) return;
        gameCancellation?.Cancel();
        boundGame = null;
        FindGhostButton.IsEnabled = false;
        SetGamePath(GameLocator.Resolve(dialog.FileName)??dialog.FileName);
        GameStatusText.Text = "GAME: DISCONNECTED · press INJECT after launching the selected executable";
    }

    private async void GameConnect_Click(object sender, RoutedEventArgs e)
    {
        if(gameExecutable is null)await DiscoverGameAsync();
        if (gameExecutable is null)
        {
            GameBrowse_Click(sender, e);
            if (gameExecutable is null) return;
        }
        gameCancellation?.Cancel();
        using var session = new CancellationTokenSource();
        gameCancellation = session;
        var service = new GameConnection();
        GameStatusText.Text = "GAME: LOCATING SELECTED PROCESS";
        RuntimeGhostReader? reader = null;
        int readerPid = 0;
        try
        {
            while (!session.IsCancellationRequested)
            {
                var found = await service.FindAsync(gameExecutable, session.Token);
                if (session.IsCancellationRequested) break;
                boundGame = found;
                FindGhostButton.IsEnabled = found is not null;
                if(found is null)
                {
                    reader?.Dispose();reader=null;readerPid=0;
                    ClearRuntimeIdentity("Waiting for the game process.");
                    SetConnection("WAITING FOR GAME", "#D7A453");
                    GameStatusText.Text="GAME: NOT RUNNING · waiting for selected executable";
                }
                else
                {
                    if(reader is null || readerPid!=found.Id)
                    {
                        reader?.Dispose();reader=null;
                        reader=await Task.Run(()=>new RuntimeGhostReader(found),session.Token);
                        readerPid=found.Id;
                    }
                    RuntimeIdentity? identity;
                    try { identity=await Task.Run(()=>reader.Read(session.Token),session.Token); }
                    catch(Exception ex) when(ex is IOException or InvalidDataException)
                    {
                        ClearRuntimeIdentity(ex.Message);
                        ErrorText.Text=Privacy.Redact(ex.Message);
                        GameStatusText.Text="GAME: WAITING FOR STABLE MATCH DATA";
                        SetConnection("RETRYING LIVE READER", "#D7A453");
                        await Task.Delay(2000,session.Token);
                        continue;
                    }
                    if(session.IsCancellationRequested)break;
                    GameStatusText.Text=$"GAME: READ-ONLY CONNECTION · PID {found.Id}";
                    SetConnection("GAME CONNECTED", "#58C39B");
                    AutoText.Text="Enabled · live runtime reader · refresh 2s";
                    if(identity is null) ClearRuntimeIdentity("Waiting for an active Identify contract.");
                    else
                    {
                        DisplayRuntimeIdentity(identity);
                        IdentityHintText.Text="Verified against the live game enum";
                        IdentityBadgeText.Text="Verified from game data";
                        SignalText.Text="Identity verified";
                        MatchText.Text=$"Active · {identity.Map}\nMatch {identity.MatchId}";
                        TimestampText.Text=$"Detected: {identity.ObservedUtc.ToLocalTime():yyyy-MM-dd HH:mm:ss zzz}";
                        ErrorText.Text=Privacy.Redact($"Read-only identity: {identity.Asset}, enum value {identity.EnumValue}. Current-match game state and ghost-manager references agree. No evidence entry required.");
                    }
                }
                await Task.Delay(2000, session.Token);
            }
        }
        catch (OperationCanceledException) when (session.IsCancellationRequested) { }
        catch (Exception ex) when (ex is IOException or InvalidDataException or UnauthorizedAccessException or ArgumentException)
        {
            if (gameCancellation == session)
            {
                boundGame = null;
                FindGhostButton.IsEnabled = false;
                GameStatusText.Text = "GAME: CONNECTION FAILED · " + ex.Message;
                ClearRuntimeIdentity(ex.Message);
                SetConnection("GAME READER ERROR", "#DE536A");
                AutoText.Text="Stopped · reconnect after resolving the error";
                ErrorText.Text=Privacy.Redact(ex.Message);
                log.Write(ex.ToString());
            }
        }
        finally { reader?.Dispose(); if (gameCancellation == session) gameCancellation = null; }
    }

    private void FindGhost_Click(object sender, RoutedEventArgs e)
    {
        GameConnect_Click(sender,e);
    }

    private void ClearRuntimeIdentity(string reason)
    {
        CurrentGhostText.Text="Unknown";
        IdentityHintText.Text=reason;
        IdentityBadgeText.Text="Waiting for live identity";
        SignalText.Text="No verified identity";
        MatchText.Text="Waiting for a match";
        TimestampText.Text="Detected: —";
        if(lastIdentity is not null)
        {
            DossierStateText.Text="LAST DETECTED RESULT · no current live identity. Previous dossier retained for reference.";
            OverviewDetailsText.Text=$"Last detected: {lastIdentity.Ghost}. Open the dossier for retained reference details.";
        }
    }

    internal void DisplayRuntimeIdentity(RuntimeIdentity identity, bool recordedPreview=false)
    {
        bool changed=lastIdentity is null || lastIdentity.MatchId!=identity.MatchId || lastIdentity.Ghost!=identity.Ghost;
        lastIdentity=identity;
        CopyGhostButton.IsEnabled=true;
        CopyGhostButton.Content="Copy ghost name";
        OverviewCopyButton.Content="Copy ghost name";
        var details=ghostReference?.Find(identity.Ghost);
        string name=details?.Name??identity.Ghost;
        CurrentGhostText.Text=name;
        if(changed && !recordedPreview)UiMotion.Reveal(CurrentGhostText);
        DossierNameText.Text=name;
        DossierStateText.Text=recordedPreview?"Recorded match preview · not a current live read":"LIVE IDENTITY · updated from the current game state";
        DossierMatchText.Text=$"{identity.Map}  /  {identity.ObservedUtc.ToLocalTime():yyyy-MM-dd HH:mm:ss zzz}\nMatch {identity.MatchId}";
        DossierEvidenceText.Text=details is null?"No reference for this ghost":string.Join("  /  ",details.Evidence);
        OverviewDetailsText.Text=details is null?"A live identity is available. No guide entry matches this name.":$"{name} · {string.Join(" / ",details.Evidence)}\nSpeed: {details.Speed} · Holy water: {details.HolyWater} effectiveness";
        DetailSpeedText.Text=details?.Speed??"Unknown";
        DetailChaseText.Text=details?.ChaseSpeed??"Unknown";
        DetailRangeText.Text=details?.DetectionRange??"Unknown";
        DetailWaterText.Text=details?.HolyWater??"Unknown";
        DetailCooldownText.Text=details?.Cooldown??"Unknown";
        BehaviorList.ItemsSource=details?.Traits??Array.Empty<string>();
        BehaviorSummaryText.Text=details is null?"No behavior reference is available for this identity.":"Reference behavior: "+string.Join("\n",details.Traits.Take(2));
        DetailReferenceText.Text=ghostReference is null?"Reference file unavailable. Live identity detection is unaffected.":$"Community reference · retrieved {ghostReference.Retrieved}\n{ghostReference.Source}\nReference categories and behaviors may differ from this installed build. They are not live measured stats.";
        if(recordedPreview)
        {
            IdentityHintText.Text="Recorded identity · confirmed by contract summary";
            IdentityBadgeText.Text="Recorded match preview";
            SignalText.Text="Recorded result";
            MatchText.Text="Recorded match / "+identity.Map;
            TimestampText.Text=$"Recorded: {identity.ObservedUtc.ToLocalTime():yyyy-MM-dd HH:mm:ss zzz}";
            AutoText.Text="Preview; monitoring inactive";
        }
    }
    private void Dossier_Click(object sender,RoutedEventArgs e)=>WorkspaceTabs.SelectedIndex=1;
    private void CopyGhost_Click(object sender,RoutedEventArgs e)
    {
        if(lastIdentity is null)return;
        try { Clipboard.SetText(ghostReference?.Find(lastIdentity.Ghost)?.Name??lastIdentity.Ghost); CopyGhostButton.Content="Copied"; OverviewCopyButton.Content="Copied"; }
        catch(System.Runtime.InteropServices.ExternalException ex){ErrorText.Text=Privacy.Redact("Clipboard unavailable: "+ex.Message);}
    }

    private void Stop()
    {
        generation++;
        manualRunning = false;
        var old = cancellation;
        cancellation = null;
        old?.Cancel();
        if (old is not null)
        {
            if (monitoring is { } previous) _ = previous.ContinueWith(_ => old.Dispose(), TaskScheduler.Default);
            else old.Dispose();
        }
        monitoring = null;
    }

    private void Connect_Click(object sender, RoutedEventArgs e)
    {
        if (!ready || identifier is null) return;
        gameCancellation?.Cancel();
        ClearRuntimeIdentity("Evidence mode selected. Press INJECT for live identity.");
        Stop();
        ClearPrediction();
        if (SourceBox.SelectedIndex == 0)
        {
            manualRunning = true;
            if (matchStatus != "Ended") matchStatus = "Active";
            SetConnection("MANUAL EVIDENCE MODE · GAME NOT CONNECTED", "#D7A453");
            AutoText.Text = "Enabled · recalculates on observations; manual match boundaries";
            RefreshManual();
            return;
        }
        string path;
        try
        {
            if (string.IsNullOrWhiteSpace(FeedPathBox.Text)) throw new ArgumentException("Select an observation JSON file. The game does not automatically create this file.");
            path = Path.GetFullPath(FeedPathBox.Text.Trim());
            if (path.StartsWith(@"\\")) throw new ArgumentException("Choose a local observation file; network shares are not supported.");
        }
        catch (Exception ex) when (ex is ArgumentException or NotSupportedException)
        { ErrorText.Text=Privacy.Redact(ex.Message); return; }
        SetConnection("CONNECTING TO OBSERVATION FEED", "#D7A453");
        AutoText.Text = "Enabled · polling 1s; automatic failure recovery";
        cancellation = new();
        int current = generation;
        var monitor = new MatchMonitor(new ObservationFileSource(path, identifier), log);
        monitoring = monitor.RunAsync(update => Dispatcher.InvokeAsync(() =>
        {
            if (generation != current) return;
            SetConnection(update.Status, update.Snapshot is null ? "#DE536A" : "#58C39B");
            if (update.Snapshot is null)
            {
                ClearPrediction();
                MatchText.Text = "Match unavailable · source unavailable";
                ErrorText.Text=Privacy.Redact(update.Error);
            }
            else Apply(update.Snapshot);
        }), cancellation.Token);
    }

    private void Apply(SessionSnapshot snapshot)
    {
        if (identifier is null) return;
        try
        {
            var result = identifier.Identify(snapshot);
            CandidateList.ItemsSource = result.Candidates.Select(x => x.Name).ToArray();
            CandidateCountText.Text = $"{result.Candidates.Length} candidate{(result.Candidates.Length == 1 ? "" : "s")}";
            PredictionText.Text = snapshot.Status != "Active" ? "POSSIBLE GHOSTS — waiting" :
                result.Candidates.Length == 1 ? $"PREDICTION — {result.Candidates[0].Name}" :
                $"{result.Candidates.Length} possible ghosts · view Evidence for the full list";
            ExplanationText.Text = result.Explanation;
            MatchText.Text = $"MATCH STATUS: {snapshot.Status.ToUpperInvariant()}  /  {snapshot.MatchId}\n{snapshot.Map} · {snapshot.Mode} · {snapshot.RealEvidenceCount} real evidence allowed";
            TimestampText.Text = $"Observed: {snapshot.ObservedUtc.ToLocalTime():yyyy-MM-dd HH:mm:ss zzz}  /  Detected: {DateTimeOffset.Now:HH:mm:ss zzz}";
            ErrorText.Text = snapshot.Mode == "Cleanse"
                ? "Cleanse is not supported by this Identify evidence catalog. No ghost prediction is made."
                : "Confirmed identity unavailable. Predictions depend on your observations and the community catalog; no confidence percentages are fabricated.";
        }
        catch (Exception ex) when (ex is IOException or InvalidDataException or ArgumentException)
        {
            ClearPrediction();
            MatchText.Text = "Invalid observations";
            ErrorText.Text=Privacy.Redact(ex.Message);
            log.Write(ex.Message);
        }
    }

    private void ClearPrediction()
    {
        CandidateList.ItemsSource = Array.Empty<string>();
        CandidateCountText.Text = "No current candidates";
        PredictionText.Text = "POSSIBLE GHOSTS — unavailable";
        TimestampText.Text = "Observed: —   /   Detected: —";
        ExplanationText.Text = "No current validated observations. Previous predictions have been cleared.";
    }

    private void RefreshManual()
    {
        if (!ready || changing || !manualRunning) return;
        Apply(new(1, MatchIdBox.Text, MapBox.Text.Trim(), ModeBox.SelectedIndex == 0 ? "Identify" : "Cleanse",
            matchStatus, DateTimeOffset.UtcNow, CountBox.SelectedIndex,
            evidenceControls.ToDictionary(x => x.Key, x => (Observation)x.Value.SelectedItem)));
    }
    private void Manual_Changed(object sender, RoutedEventArgs e) => RefreshManual();
    private void ResetMatch()
    {
        changing = true;
        MatchIdBox.Text = Guid.NewGuid().ToString("N")[..12];
        matchStatus = manualRunning ? "Active" : "Waiting";
        foreach (var box in evidenceControls.Values) box.SelectedIndex = 0;
        changing = false;
        ClearPrediction();
        MatchText.Text = "MATCH STATUS: " + matchStatus.ToUpperInvariant();
        RefreshManual();
    }
    private void NewMatch_Click(object sender, RoutedEventArgs e) => ResetMatch();
    private void EndMatch_Click(object sender, RoutedEventArgs e) { matchStatus = "Ended"; RefreshManual(); }
    private void Stop_Click(object sender, RoutedEventArgs e)
    {
        gameCancellation?.Cancel();
        boundGame = null;
        FindGhostButton.IsEnabled = false;
        GameStatusText.Text = "GAME: DISCONNECTED";
        ClearRuntimeIdentity("Game reader disconnected.");
        Stop(); ClearPrediction();
        SetConnection("DISCONNECTED", "#727783");
        MatchText.Text = "Waiting for a match";
        AutoText.Text = "Stopped";
    }
    private void Source_Changed(object sender, SelectionChangedEventArgs e)
    {
        if (!ready) return;
        Stop_Click(sender, e);
        bool manual = SourceBox.SelectedIndex == 0;
        FeedPathBox.IsEnabled = !manual;
        ManualPanel.IsEnabled = EvidencePanel.IsEnabled = NewMatchButton.IsEnabled = EndMatchButton.IsEnabled = manual;
    }
    private void Browse_Click(object sender, RoutedEventArgs e)
    {
        var dialog = new OpenFileDialog { Filter = "Observation files (*.json)|*.json", CheckFileExists = false };
        if (dialog.ShowDialog() == true) { Stop_Click(sender, e); FeedPathBox.Text = dialog.FileName; }
    }
    private void Logs_Click(object sender, RoutedEventArgs e)
    {
        try { Directory.CreateDirectory(log.DirectoryPath); Process.Start(new ProcessStartInfo(log.DirectoryPath) { UseShellExecute = true }); }
        catch (Exception ex) { ErrorText.Text=Privacy.Redact("Cannot open logs: " + ex.Message); }
    }
    private void SetConnection(string text, string color)
    { ConnectionText.Text = text; StatusDot.Fill = (Brush)new BrushConverter().ConvertFromString(color)!; }

    protected override void OnSourceInitialized(EventArgs e)
    {
        base.OnSourceInitialized(e);
        if(SystemParameters.HighContrast)return;
        int enabled=1;
        try { DwmSetWindowAttribute(new System.Windows.Interop.WindowInteropHelper(this).Handle,20,ref enabled,sizeof(int)); }
        catch(DllNotFoundException) { }
        catch(EntryPointNotFoundException) { }
    }
    [System.Runtime.InteropServices.DllImport("dwmapi.dll")]
    private static extern int DwmSetWindowAttribute(nint window,int attribute,ref int value,int size);
}
