using System.Diagnostics;
using System.IO;
using System.Text.Json;
using System.Text.RegularExpressions;
using Microsoft.Win32;
namespace GhostDetector;
public sealed class GameLocator
{
    public const string ShippingName="TheOtherSide-Win64-Shipping.exe";
    public static string? Resolve(string path)
    {
        if(string.IsNullOrWhiteSpace(path))return null;
        string full=Path.GetFullPath(path);
        if(File.Exists(full)&&Path.GetFileName(full).Equals(ShippingName,StringComparison.OrdinalIgnoreCase))return full;
        string folder=Directory.Exists(full)?full:Path.GetDirectoryName(full)!;
        foreach(string relative in new[]{ShippingName,Path.Combine("Binaries","Win64",ShippingName),Path.Combine("TheOtherSide","Binaries","Win64",ShippingName)})
        {string candidate=Path.Combine(folder,relative);if(File.Exists(candidate))return candidate;}
        return null;
    }
    public Task<string?> LocateAsync(CancellationToken token)=>Task.Run(()=>
    {
        if(!OperatingSystem.IsWindows())return null;
        foreach(string name in new[]{"TheOtherSide-Win64-Shipping","TheOtherSide"})
            foreach(var process in Process.GetProcessesByName(name))using(process)
            {
                token.ThrowIfCancellationRequested();
                try {if(process.MainModule?.FileName is string path && Resolve(path) is string found)return found;}
                catch(Exception ex) when(ex is System.ComponentModel.Win32Exception or InvalidOperationException or IOException) { }
            }
        if(LocalGameSettings.Load() is string saved && Resolve(saved) is string cached)return cached;
        var roots=new HashSet<string>(StringComparer.OrdinalIgnoreCase);
        foreach(string key in new[]{@"HKEY_CURRENT_USER\Software\Valve\Steam",@"HKEY_LOCAL_MACHINE\SOFTWARE\WOW6432Node\Valve\Steam"})
        {
            try
            {
                string? steam=Registry.GetValue(key,"SteamPath",null) as string ?? Registry.GetValue(key,"InstallPath",null) as string;
                if(steam is null)continue;
                roots.Add(Path.Combine(steam,"steamapps","common"));
                string file=Path.Combine(steam,"steamapps","libraryfolders.vdf");
                if(File.Exists(file))foreach(Match m in Regex.Matches(File.ReadAllText(file),"\"path\"\\s*\"([^\"]+)\""))
                    roots.Add(Path.Combine(m.Groups[1].Value.Replace(@"\\",@"\"),"steamapps","common"));
            }
            catch(Exception ex) when(ex is IOException or UnauthorizedAccessException or System.Security.SecurityException) { }
        }
        string profile=Environment.GetFolderPath(Environment.SpecialFolder.UserProfile);
        foreach(string root in new[]{Path.Combine(profile,"Downloads"),Environment.GetFolderPath(Environment.SpecialFolder.DesktopDirectory),Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ProgramFilesX86),"Steam","steamapps","common"),AppContext.BaseDirectory})
            if(!string.IsNullOrEmpty(root))roots.Add(root);
        return FindInRoots(roots,token);
    },token);
    public static string? FindInRoots(IEnumerable<string> roots,CancellationToken token)
    {
        var queue=new Queue<(string Path,int Depth)>();
        foreach(string root in roots)if(Directory.Exists(root))queue.Enqueue((root,0));
        var visited=new HashSet<string>(StringComparer.OrdinalIgnoreCase);
        var elapsed=Stopwatch.StartNew();
        while(queue.Count>0&&visited.Count<3000&&elapsed.Elapsed<TimeSpan.FromSeconds(8))
        {
            token.ThrowIfCancellationRequested();var item=queue.Dequeue();
            if(!visited.Add(item.Path))continue;
            try
            {
                if((File.GetAttributes(item.Path)&FileAttributes.ReparsePoint)!=0)continue;
                if(Resolve(item.Path) is string found)return found;
                if(item.Depth>=5)continue;
                foreach(string child in Directory.EnumerateDirectories(item.Path))queue.Enqueue((child,item.Depth+1));
            }
            catch(Exception ex) when(ex is IOException or UnauthorizedAccessException or System.Security.SecurityException) { }
        }
        return null;
    }
}
public static class LocalGameSettings
{
    private static string SettingsPath=>Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData),"OtherSideGhostDetector","settings.json");
    public static string? Load()
    {
        try{return JsonSerializer.Deserialize<Dictionary<string,string>>(File.ReadAllText(SettingsPath))?.GetValueOrDefault("gameExecutable");}
        catch(Exception ex) when(ex is IOException or UnauthorizedAccessException or JsonException){return null;}
    }
    public static void Save(string executable)
    {
        try {Directory.CreateDirectory(Path.GetDirectoryName(SettingsPath)!);File.WriteAllText(SettingsPath,JsonSerializer.Serialize(new{gameExecutable=executable}));}
        catch(Exception ex) when(ex is IOException or UnauthorizedAccessException) { }
    }
}
