using System.Text.RegularExpressions;
namespace GhostDetector;
public static class Privacy
{
    public static string Redact(string? text)=>Regex.Replace(text??"",@"[A-Za-z]:[\\/]Users[\\/][^\\/\r\n""<>]+","%USERPROFILE%",RegexOptions.IgnoreCase);
}
