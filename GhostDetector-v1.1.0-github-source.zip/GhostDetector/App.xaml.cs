using System.Windows;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.IO;
namespace GhostDetector;
public partial class App : Application
{
    protected override async void OnStartup(StartupEventArgs e)
    {
        base.OnStartup(e);
        if(e.Args.Length==2 && e.Args[0]=="--discover-check")
        {
            string? located=await new GameLocator().LocateAsync(CancellationToken.None);
            File.WriteAllText(e.Args[1],System.Text.Json.JsonSerializer.Serialize(new{Found=located is not null,Path=Privacy.Redact(located)},Json.Options));
            Shutdown();return;
        }
        if(e.Args.Length==4 && e.Args[0]=="--runtime-check")
        {
            try
            {
                using var reader=new RuntimeGhostReader(new(int.Parse(e.Args[1]),e.Args[2]));
                var result=reader.Read(CancellationToken.None);
                File.WriteAllText(e.Args[3],System.Text.Json.JsonSerializer.Serialize(result,Json.Options));
                Shutdown(0);
            }
            catch(Exception ex){File.WriteAllText(e.Args[3],ex.ToString());Shutdown(1);}
            return;
        }
        UiMotion.Suppress=e.Args.Length>0 && e.Args[0]=="--preview";
        var window = new MainWindow();
        if(e.Args.Length==2 && e.Args[0]=="--motion-check")
        {
            try {await MotionValidation.RunAsync(window,Path.GetFullPath(e.Args[1]));Shutdown(0);}
            catch(Exception ex){Directory.CreateDirectory(e.Args[1]);File.WriteAllText(Path.Combine(e.Args[1],"failure.txt"),ex.ToString());Shutdown(1);}
            return;
        }
        if (e.Args.Length >= 2 && e.Args[0] == "--preview")
        {
            // Render this application's own visual tree; never capture a desktop/window.
            double width = e.Args.Length > 2 ? double.Parse(e.Args[2], System.Globalization.CultureInfo.InvariantCulture) : 1240;
            double height = e.Args.Length > 3 ? double.Parse(e.Args[3], System.Globalization.CultureInfo.InvariantCulture) : 860;
            if (e.Args.Length > 4) window.WorkspaceTabs.SelectedIndex = int.Parse(e.Args[4]);
            if(e.Args.Length>5)
            {
                var recorded=System.Text.Json.JsonSerializer.Deserialize<RuntimeIdentity>(File.ReadAllText(e.Args[5]),Json.Options);
                if(recorded is not null)window.DisplayRuntimeIdentity(recorded,true);
            }
            var root = (FrameworkElement)window.Content;
            root.Measure(new Size(width, height)); root.Arrange(new Rect(0,0,width,height)); root.UpdateLayout();
            var image = new RenderTargetBitmap((int)width,(int)height,96,96,PixelFormats.Pbgra32);
            image.Render(root);
            var encoder = new PngBitmapEncoder(); encoder.Frames.Add(BitmapFrame.Create(image));
            using (var stream = File.Create(Path.GetFullPath(e.Args[1]))) encoder.Save(stream);
            Shutdown();
        }
        else
        {
            MainWindow = window;
            window.Show();
            if (SystemParameters.ClientAreaAnimation && !SystemParameters.HighContrast)
                window.BeginAnimation(UIElement.OpacityProperty, new System.Windows.Media.Animation.DoubleAnimation(0,1,TimeSpan.FromMilliseconds(180)));
        }
    }
}
