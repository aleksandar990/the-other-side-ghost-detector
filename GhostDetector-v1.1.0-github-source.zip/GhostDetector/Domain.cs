using System.IO;
using System.Text.Json;
using System.Text.Json.Serialization;

namespace GhostDetector;

public sealed record Ghost(string Name, string[] Evidence, string? Forced);
public sealed record Catalog(string Source, string RetrievedUtc, string Version, string[] EvidenceTypes, Ghost[] Ghosts)
{
    public static Catalog Load(string path)
    {
        var c = JsonSerializer.Deserialize<Catalog>(File.ReadAllText(path), Json.Options)
            ?? throw new InvalidDataException("The gameplay catalog is empty.");
        if (c.Ghosts.Length == 0 || c.EvidenceTypes.Length == 0 || string.IsNullOrWhiteSpace(c.Source))
            throw new InvalidDataException("Catalog has no source, ghosts, or evidence definitions.");
        if (c.Ghosts.Select(g => g.Name).Distinct(StringComparer.OrdinalIgnoreCase).Count() != c.Ghosts.Length)
            throw new InvalidDataException("Catalog contains duplicate ghost names.");
        foreach (var g in c.Ghosts)
            if (string.IsNullOrWhiteSpace(g.Name) || g.Evidence.Length != 3 || g.Evidence.Distinct().Count() != 3 ||
                g.Evidence.Any(e => !c.EvidenceTypes.Contains(e)) || (g.Forced is not null && !g.Evidence.Contains(g.Forced)))
                throw new InvalidDataException($"Invalid catalog entry: {g.Name}");
        return c;
    }
}
public enum Observation { Unknown, Real, Diminishing, RuledOut }
public sealed record SessionSnapshot(int SchemaVersion, string MatchId, string Map, string Mode,
    string Status, DateTimeOffset ObservedUtc, int RealEvidenceCount,
    Dictionary<string, Observation> Evidence);
public sealed record Prediction(Ghost[] Candidates, string Explanation);

public static class Json
{
    public static readonly JsonSerializerOptions Options = new()
    {
        PropertyNameCaseInsensitive = true,
        WriteIndented = true,
        Converters = { new JsonStringEnumConverter() }
    };
}

public sealed class EvidenceIdentifier(Catalog catalog)
{
    public Prediction Identify(SessionSnapshot s)
    {
        Validate(s);
        if (s.Mode != "Identify") return new([], "Evidence filtering applies only to Identify contracts. Current mode: " + s.Mode);
        if (s.Status != "Active") return new([], "Waiting for an active match. No identity is confirmed.");
        var real = s.Evidence.Where(x => x.Value == Observation.Real).Select(x => x.Key).ToHashSet();
        if (real.Count > s.RealEvidenceCount)
            throw new InvalidDataException("More real evidence is marked than this contract allows. Recheck diminishing evidence and the contract settings.");
        var excluded = s.Evidence.Where(x => x.Value == Observation.RuledOut).Select(x => x.Key).ToHashSet();
        // Diminishing observations never exclude: limited-evidence contracts and special behaviors
        // can produce misleading observations. Absence must be explicitly ruled out by the player.
        var candidates = catalog.Ghosts.Where(g => real.All(g.Evidence.Contains) &&
            !excluded.Any(g.Evidence.Contains) &&
            !(s.RealEvidenceCount is > 0 and < 3 && real.Count == s.RealEvidenceCount &&
              g.Forced is not null && !real.Contains(g.Forced))).ToArray();
        return new(candidates, candidates.Length == 0
            ? "No catalog match. Recheck evidence, contract settings, game version, and special behaviors."
            : "PREDICTION ONLY • player-observed evidence • community catalog. Diminishing observations do not exclude ghosts. A sole candidate is never a confirmed identity.");
    }

    public void Validate(SessionSnapshot s)
    {
        if (s.SchemaVersion != 1) throw new InvalidDataException("Unsupported observation schema. Expected schemaVersion 1.");
        if (string.IsNullOrWhiteSpace(s.MatchId) || s.MatchId.Length > 200 || string.IsNullOrWhiteSpace(s.Map))
            throw new InvalidDataException("A matchId (1–200 characters) and map are required.");
        if (s.Status is not ("Active" or "Waiting" or "Ended")) throw new InvalidDataException("status must be Active, Waiting, or Ended.");
        if (s.Mode is not ("Identify" or "Cleanse")) throw new InvalidDataException("mode must be Identify or Cleanse.");
        if (s.RealEvidenceCount is < 0 or > 3) throw new InvalidDataException("realEvidenceCount must be 0–3.");
        if (s.Evidence is null || s.Evidence.Any(x => !catalog.EvidenceTypes.Contains(x.Key) || !Enum.IsDefined(x.Value)))
            throw new InvalidDataException("Unknown evidence key or observation value.");
        if (s.Evidence.GetValueOrDefault("Freezing") == Observation.Diminishing)
            throw new InvalidDataException("The catalog does not support diminishing Freezing. Recheck the observation.");
        if (s.ObservedUtc == default || s.ObservedUtc > DateTimeOffset.UtcNow.AddSeconds(10))
            throw new InvalidDataException("observedUtc is missing or in the future. Check the producer's clock.");
    }
}
