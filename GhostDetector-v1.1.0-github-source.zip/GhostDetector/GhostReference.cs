using System.IO;
using System.Text.Json;

namespace GhostDetector;

public sealed record GhostDetails(string Name,string[] Evidence,string Speed,string ChaseSpeed,string DetectionRange,string HolyWater,string Cooldown,string[] Traits);
public sealed record GhostReference(string Source,string Retrieved,GhostDetails[] Ghosts)
{
    public static GhostReference Load(string path)
    {
        var reference=JsonSerializer.Deserialize<GhostReference>(File.ReadAllText(path),Json.Options)
            ?? throw new InvalidDataException("Ghost reference is empty.");
        if(string.IsNullOrWhiteSpace(reference.Source) || reference.Ghosts is null || reference.Ghosts.Length==0 ||
            reference.Ghosts.Any(g=>string.IsNullOrWhiteSpace(g.Name)||g.Evidence is null||g.Traits is null)||
            reference.Ghosts.GroupBy(g=>Normalize(g.Name)).Any(g=>g.Count()>1))
            throw new InvalidDataException("Ghost reference has invalid entries.");
        return reference;
    }
    public GhostDetails? Find(string runtimeName)
    {
        string key=Normalize(runtimeName);
        return Ghosts.SingleOrDefault(g=>Normalize(g.Name)==key);
    }
    private static string Normalize(string name)
    {
        var key=new string(name.Where(char.IsLetterOrDigit).Select(char.ToLowerInvariant).ToArray());
        if(key.StartsWith("the",StringComparison.Ordinal))key=key[3..];
        return key=="doppleganger"?"doppelganger":key;
    }
}
