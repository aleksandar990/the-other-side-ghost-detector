using System.IO;
using System.Text.Json;

namespace GhostDetector;

public interface IObservationSource
{
    Task<SessionSnapshot> ReadAsync(CancellationToken cancellationToken);
}

// This is OUR interchange format, not a claimed game API. No ghost-identity field is accepted.
public sealed class ObservationFileSource(string path, EvidenceIdentifier identifier) : IObservationSource
{
    public async Task<SessionSnapshot> ReadAsync(CancellationToken cancellationToken)
    {
        await using var file = new FileStream(path, FileMode.Open, FileAccess.Read,
            FileShare.ReadWrite | FileShare.Delete, 4096, FileOptions.Asynchronous);
        if (file.Length > 65536) throw new InvalidDataException("Observation file exceeds the 64 KiB limit.");
        // Bound reads even if a producer grows the file after opening it.
        byte[] data = new byte[65537];
        int read = 0;
        while (read < data.Length)
        {
            int n = await file.ReadAsync(data.AsMemory(read), cancellationToken);
            if (n == 0) break;
            read += n;
        }
        if (read > 65536) throw new InvalidDataException("Observation file exceeds the 64 KiB limit.");
        var s = JsonSerializer.Deserialize<SessionSnapshot>(data.AsSpan(0, read), Json.Options)
            ?? throw new InvalidDataException("Observation file contains null.");
        identifier.Validate(s);
        if (DateTimeOffset.UtcNow - s.ObservedUtc > TimeSpan.FromSeconds(30))
            throw new InvalidDataException("Observation feed is stale (>30 seconds). Update its heartbeat; previous predictions have been cleared.");
        return s;
    }
}

public sealed record MonitorUpdate(SessionSnapshot? Snapshot, string Status, string? Error);

public sealed class MatchMonitor(IObservationSource source, AppLog log)
{
    public async Task RunAsync(Action<MonitorUpdate> publish, CancellationToken token)
    {
        int failures = 0;
        while (!token.IsCancellationRequested)
        {
            try
            {
                var snapshot = await source.ReadAsync(token);
                publish(new(snapshot, "OBSERVATION FEED CONNECTED", null));
                failures = 0;
            }
            catch (OperationCanceledException) when (token.IsCancellationRequested) { break; }
            catch (Exception ex) when (ex is IOException or InvalidDataException or UnauthorizedAccessException or JsonException or ArgumentException or NotSupportedException)
            {
                failures++;
                string message = $"{ex.GetType().Name}: {ex.Message}";
                if (failures == 1) log.Write(message);
                publish(new(null, "FEED UNAVAILABLE · RETRYING", message));
            }
            try { await Task.Delay(TimeSpan.FromSeconds(failures == 0 ? 1 : Math.Min(10, failures * 2)), token); }
            catch (OperationCanceledException) when (token.IsCancellationRequested) { break; }
        }
    }
}

public sealed class AppLog
{
    private readonly object gate = new();
    public string DirectoryPath { get; } = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), "OtherSideGhostDetector", "Logs");
    public void Write(string message)
    {
        try
        {
            lock (gate)
            {
                Directory.CreateDirectory(DirectoryPath);
                string path = Path.Combine(DirectoryPath, $"{DateTime.UtcNow:yyyy-MM-dd}.log");
                if (File.Exists(path) && new FileInfo(path).Length > 2_000_000) return;
                File.AppendAllText(path, $"{DateTimeOffset.UtcNow:O} {Privacy.Redact(message)}{Environment.NewLine}");
            }
        }
        catch (Exception ex) when (ex is IOException or UnauthorizedAccessException) { System.Diagnostics.Debug.WriteLine(ex); }
    }
}
