using System.IO;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Threading;
using System.Windows.Interop;

namespace GhostDetector;

internal static class MotionValidation
{
    // Exercises real WPF animation clocks on this app's own visual tree.
    internal static async Task RunAsync(MainWindow window,string output)
    {
        Directory.CreateDirectory(output);
        var root=(FrameworkElement)window.Content;
        // A hidden presentation source gives WPF a rendering clock without
        // showing a window or capturing any desktop pixels.
        window.Content=null;
        using var presentation=new HwndSource(new HwndSourceParameters("GhostDetectorMotionValidation")
        {WindowStyle=0,Width=1120,Height=820});
        presentation.RootVisual=root;
        root.Measure(new Size(1120,820));root.Arrange(new Rect(0,0,1120,820));root.UpdateLayout();
        var checks=new List<string>();
        void Check(bool passed,string description)
        {if(!passed)throw new InvalidOperationException(description);checks.Add(description);}
        bool windowsPreference=UiMotion.CanAnimate;
        // Exercise clocks even on a test machine with OS animations disabled.
        // This switch is used only by this diagnostic command, never normal startup.
        UiMotion.ValidationOverride=true;
        bool motion=UiMotion.CanAnimate;
        var original=root.RenderSize;
        var page=(UIElement)window.WorkspaceTabs.SelectedContent;
        UiMotion.Reveal(page);
        // WPF starts newly created clocks on the next dispatcher/render tick.
        await Delay(25);
        double first=page.Opacity;
        Save(root,Path.Combine(output,"tab-start.png"));
        await Delay(80);
        double middle=page.Opacity;
        Save(root,Path.Combine(output,"tab-middle.png"));
        await Delay(250);
        double final=page.Opacity;
        Save(root,Path.Combine(output,"tab-settled.png"));
        Check(Math.Abs(final-1)<0.001,"Tab transition settles at full opacity");
        Check(!motion || first<1,$"Tab transition starts with a fade (first={first:F3}, middle={middle:F3})");
        Check(!motion || middle>first,"Tab fade advances over real dispatcher time");
        Check(root.RenderSize==original,"Motion preserves layout dimensions");
        UiMotion.Reveal(page);UiMotion.Reveal(page);
        await Delay(260);
        Check(Math.Abs(page.Opacity-1)<0.001,"Rapid repeated transitions settle cleanly");
        var button=window.InjectButton;
        UiMotion.Feedback(button,0.07);
        await Delay(180);
        var overlay=(Border)button.Template.FindName("HoverOverlay",button);
        Check(Math.Abs(overlay.Opacity-0.07)<0.001,"Hover feedback reaches its target");
        Save(root,Path.Combine(output,"button-hover.png"));
        UiMotion.Feedback(button,0.15);
        await Delay(100);
        Check(Math.Abs(overlay.Opacity-0.15)<0.001,"Press feedback reaches its target");
        Save(root,Path.Combine(output,"button-pressed.png"));
        UiMotion.Feedback(button,0);
        await Delay(180);
        Check(overlay.Opacity<0.001,"Button feedback returns to rest");
        UiMotion.Feedback(button,0.15);button.IsEnabled=false;
        await Delay(180);
        Check(overlay.Opacity<0.001,"Disabling a button clears animated feedback");
        button.IsEnabled=true;
        UiMotion.Suppress=true;
        UiMotion.Reveal(page);UiMotion.Feedback(button,0.07);
        Check(page.Opacity==1 && overlay.Opacity==0.07,"Suppressed motion applies the final state immediately");
        Check(!page.HasAnimatedProperties,"Suppressed page has no running animation clock");
        UiMotion.ValidationOverride=false;
        File.WriteAllText(Path.Combine(output,"checks.json"),System.Text.Json.JsonSerializer.Serialize(new {WindowsAnimationsEnabled=windowsPreference,AnimationClocksTested=motion,First=first,Middle=middle,Final=final,Checks=checks},Json.Options));
    }
    private static Task Delay(int milliseconds)
    {
        var done=new TaskCompletionSource();
        var timer=new DispatcherTimer {Interval=TimeSpan.FromMilliseconds(milliseconds)};
        timer.Tick+=(_,_)=>{timer.Stop();done.SetResult();};
        timer.Start();return done.Task;
    }
    private static void Save(FrameworkElement root,string file)
    {
        root.UpdateLayout();
        var bitmap=new RenderTargetBitmap(1120,820,96,96,PixelFormats.Pbgra32);
        bitmap.Render(root);
        var encoder=new PngBitmapEncoder();encoder.Frames.Add(BitmapFrame.Create(bitmap));
        using var stream=File.Create(file);encoder.Save(stream);
    }
}
