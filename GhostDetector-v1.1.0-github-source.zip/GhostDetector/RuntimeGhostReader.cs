using System.Buffers.Binary;
using System.Diagnostics;
using System.IO;
using System.Runtime.InteropServices;
using System.Security.Cryptography;
using System.Text;
using Microsoft.Win32.SafeHandles;

namespace GhostDetector;

public sealed record RuntimeIdentity(string Ghost, string Asset, long EnumValue, string MatchId, string Map, DateTimeOffset ObservedUtc);

// Profile derived from the supplied executable and cross-checked against live
// object metadata. Offsets are accepted only for this exact binary fingerprint.
public sealed class RuntimeGhostReader : IDisposable
{
    public const string SupportedSha256 = "20c4fcb0cba38320de5c9ae0b4f6f67bf500f24eef670f2e2d73188596f61e65";
    private const ulong NamePoolRva = 147801984, ObjectsRva = 148550944;
    private readonly SafeProcessHandle handle;
    private readonly ulong imageBase;
    private readonly int pid;
    private readonly Dictionary<uint,string> names = new();
    private readonly Dictionary<ulong,string> classes = new();
    private sealed record Obj(ulong Address, int Index, string Name, string Class, ulong Outer);

    public RuntimeGhostReader(GameProcess game)
    {
        using var file = File.OpenRead(game.ExecutablePath);
        var hash = Convert.ToHexString(SHA256.HashData(file));
        if (!hash.Equals(SupportedSha256, StringComparison.OrdinalIgnoreCase))
            throw new InvalidDataException("Unsupported game build. This reader requires the independently inspected executable fingerprint; no offsets were applied.");
        using var process = Process.GetProcessById(game.Id);
        imageBase = (ulong)(process.MainModule?.BaseAddress.ToInt64() ?? throw new IOException("Game module is unavailable."));
        pid = game.Id;
        handle = OpenProcess(0x410, false, game.Id); // QUERY_INFORMATION | VM_READ only
        if (handle.IsInvalid) { handle.Dispose(); throw new IOException("Windows denied read-only game access. " + new System.ComponentModel.Win32Exception(Marshal.GetLastWin32Error()).Message); }
        try
        {
            if (Name(0) != "None") throw new InvalidDataException("Runtime name-pool validation failed.");
            ulong chunk = Q(Q(imageBase+ObjectsRva));
            for (int i=0;i<3;i++)
                if (Object(Q(chunk+(ulong)i*24))?.Index != i) throw new InvalidDataException("Runtime object-array validation failed.");
        }
        catch { handle.Dispose(); throw; }
    }

    public RuntimeIdentity? Read(CancellationToken token)
    {
        classes.Clear();
        var states = new List<Obj>();
        Obj? enumeration = null;
        byte[] header = Bytes(imageBase+ObjectsRva,32);
        ulong chunks = U64(header,0);
        int count = I32(header,20), capacity=I32(header,16), chunkCount=I32(header,28);
        if (count < 3 || count > 2_000_000 || capacity<count || chunkCount<1 || chunkCount>64)
            throw new InvalidDataException("Runtime object inventory changed or failed validation.");
        for (int ci=0;ci<(count+65535)/65536;ci++)
        {
            token.ThrowIfCancellationRequested();
            int take=Math.Min(65536,count-ci*65536);
            byte[] entries=Bytes(Q(chunks+(ulong)ci*8),take*24);
            for(int i=0;i<take;i++)
            {
                if ((i&1023)==0) token.ThrowIfCancellationRequested();
                ulong address=U64(entries,i*24);
                if (!Pointer(address)) continue;
                Obj? o=Object(address);
                if (o is null || o.Index!=ci*65536+i || o.Name.StartsWith("Default__",StringComparison.Ordinal)) continue;
                if(o.Class=="BP_GameState_Identify_C") states.Add(o);
                if(o.Class=="Enum" && o.Name=="EGhostType") enumeration=o;
            }
        }
        if (states.Count==0) return null;
        if (enumeration is null) throw new InvalidDataException("The live ghost enum could not be validated.");
        var enumValues = ReadEnum(enumeration.Address);
        var identities=new List<RuntimeIdentity>();
        foreach(var state in states)
        {
            Obj? level=Object(state.Outer), world=level is null ? null : Object(level.Outer);
            if(level?.Class!="Level" || world?.Class!="World" || !world.Name.StartsWith("Level_Contract_",StringComparison.Ordinal)) continue;
            ulong managerAddress=Q(state.Address+0x320); // verified native GetGhostManager
            Obj? manager=Object(managerAddress);
            if(manager?.Class!="BP_GhostManager_C" || manager.Outer!=state.Outer) continue;
            ulong dataAddress=Q(manager.Address+0x2a8); // reflected AGhostManager.GhostData
            Obj? data=Object(dataAddress);
            if(data?.Class!="GhostData") continue;
            int value=Bytes(data.Address+0x40,1)[0]; // reflected GhostData.GhostType
            if(!enumValues.TryGetValue(value,out string? ghost) || value<2 || ghost.EndsWith("::MAX",StringComparison.Ordinal)) continue;
            // Re-read the complete identity chain after enumeration to reject transitions.
            if(Object(state.Address)!=state || Q(state.Address+0x320)!=manager.Address ||
                Q(manager.Address+0x2a8)!=data.Address || Bytes(data.Address+0x40,1)[0]!=value) continue;
            identities.Add(new(ghost.Split("::",StringSplitOptions.None)[^1],data.Name,value,
                $"{pid}:{world.Index}:{state.Index}",world.Name,DateTimeOffset.UtcNow));
        }
        if(identities.Count>1) throw new InvalidDataException("Multiple contract worlds are present. Waiting for an unambiguous current match.");
        return identities.SingleOrDefault();
    }

    private Dictionary<long,string> ReadEnum(ulong address)
    {
        byte[] h=Bytes(address+0x40,16);int count=I32(h,8);
        if(count<3 || count>100) throw new InvalidDataException("Ghost enum shape is unsupported.");
        byte[] data=Bytes(U64(h,0),count*16);var result=new Dictionary<long,string>();
        for(int i=0;i<count;i++)
        {
            string label=Name(U32(data,i*16));long value=BinaryPrimitives.ReadInt64LittleEndian(data.AsSpan(i*16+8,8));
            if(!label.StartsWith("EGhostType::",StringComparison.Ordinal) || !result.TryAdd(value,label))
                throw new InvalidDataException("Ghost enum entry failed validation.");
        }
        return result;
    }

    private Obj? Object(ulong address)
    {
        if(!Pointer(address)) return null;
        byte[]? b=TryBytes(address,40);if(b is null) return null;
        ulong vt=U64(b,0), cls=U64(b,16);int index=I32(b,12);
        // A virtual table must belong to this image. Reject destroyed objects.
        if(vt<imageBase || vt>=imageBase+0x9900000 || !Pointer(cls) || index<0 || (U32(b,8)&0x18000)!=0) return null;
        string n=Name(U32(b,24));if(n.Length==0) return null;
        if(!classes.TryGetValue(cls,out string? cn))
        {
            byte[]? cb=TryBytes(cls,32);if(cb is null)return null;
            cn=Name(U32(cb,24));if(cn.Length==0)return null;
            classes[cls]=cn;
        }
        return new(address,index,n,cn,U64(b,32));
    }
    private string Name(uint index)
    {
        if(names.TryGetValue(index,out var n))return n;
        if(index>>16>8191)return "";
        ulong block=Q(imageBase+NamePoolRva+16+(index>>16)*8UL);
        byte[]? h=TryBytes(block+(index&65535)*2UL,2);if(h is null)return "";
        ushort header=BinaryPrimitives.ReadUInt16LittleEndian(h);int len=header>>6;
        if(len<1 || len>255)return "";
        byte[]? b=TryBytes(block+(index&65535)*2UL+2,len*((header&1)!=0?2:1));if(b is null)return "";
        n=((header&1)!=0?Encoding.Unicode:Encoding.ASCII).GetString(b);names[index]=n;return n;
    }
    private static bool Pointer(ulong p)=>p>65536 && p<0x7fffffffffff && (p&7)==0;
    private byte[] Bytes(ulong a,int n)=>TryBytes(a,n)??throw new IOException("Game data became unreadable. Previous identity cleared; waiting for a stable session.");
    private byte[]? TryBytes(ulong a,int n)
    {
        if(a<65536 || a>0x7fffffffffff || n<1 || n>2_000_000)return null;
        byte[] b=new byte[n];return ReadProcessMemory(handle,(nint)a,b,(nuint)n,out nuint got)&&got==(nuint)n?b:null;
    }
    private ulong Q(ulong a){var b=TryBytes(a,8);return b is null?0:U64(b,0);}
    private static ulong U64(byte[] b,int i)=>BinaryPrimitives.ReadUInt64LittleEndian(b.AsSpan(i,8));
    private static uint U32(byte[] b,int i)=>BinaryPrimitives.ReadUInt32LittleEndian(b.AsSpan(i,4));
    private static int I32(byte[] b,int i)=>BinaryPrimitives.ReadInt32LittleEndian(b.AsSpan(i,4));
    public void Dispose()=>handle.Dispose();
    [DllImport("kernel32.dll",SetLastError=true)] private static extern SafeProcessHandle OpenProcess(uint access,bool inherit,int pid);
    [DllImport("kernel32.dll",SetLastError=true)] private static extern bool ReadProcessMemory(SafeProcessHandle process,nint address,[Out] byte[] buffer,nuint size,out nuint read);
}
